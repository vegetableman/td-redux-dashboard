export const GRID_CELL = 'grid_cell';
